import React from "react";
import { Link } from "react-router-dom";
import "./HomePage.css"; // styling alag rakhi hai

function HomePage({ isLoggedIn, user }) {
  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.reload();
  };

  return (
    <div className="homepage">
      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <h2 className="logo">FlowNest</h2>
        </div>
        <div className="nav-right">
          {isLoggedIn ? (
            <>
              <span>Welcome, {user?.name || "User"}!</span>
              <Link to="/admin" className="btn admin-btn">Admin</Link>
              <button onClick={handleLogout} className="btn logout-btn">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn login-btn">Login</Link>
              <Link to="/login" className="btn register-btn">Register</Link>
            </>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <header className="hero">
        <h1>Welcome to FlowNest</h1>
        <p>Streamline your HR onboarding, approvals, and workflows in one place.</p>
        {isLoggedIn ? (
          <div>
            <p>You are logged in. Go to your dashboard or admin panel.</p>
            <Link to="/admin" className="btn cta-btn">Go to Dashboard</Link>
          </div>
        ) : (
          <Link to="/login" className="btn cta-btn">Get Started</Link>
        )}
      </header>
    </div>
  );
}

export default HomePage;
